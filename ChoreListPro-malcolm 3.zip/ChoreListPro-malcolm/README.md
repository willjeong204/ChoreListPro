# OnTask

Chore organizing iOS application that will allow households to organize chores amongst one another. 
