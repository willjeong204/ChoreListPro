//
//  ViewController.swift
//  onTask Project 2
//
//  Created by Jackie Wang on 4/26/18.
//  Copyright © 2018 Jackie Wang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var taskNameLabel: UIButton!

    @IBOutlet weak var date: UILabel!
    
    var checked = false;
    let checkMark = UIImage(named: "checked box") as UIImage!
    let uncheckMark = UIImage(named: "unchecked box") as UIImage!
    
    @IBAction func checkBoxTouched(_ sender: UIButton) {

        checked = !checked
        
        
        if checked{
            sender.setBackgroundImage(checkMark, for: .normal)
            
        }
        else{
            sender.setBackgroundImage(uncheckMark, for: .normal)
            
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let currDate = Date()
        self.date.text = currDate.toString(dateFormat: "dd-MMM-yyyy")

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    
}

extension Date
{
    func toString( dateFormat format  : String ) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
    
}

